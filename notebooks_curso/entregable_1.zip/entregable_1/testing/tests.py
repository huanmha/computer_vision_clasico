import numpy as np
import matplotlib.pyplot as plt
import os

def test_marching_squares(marching_squares_func):
    """
    Test de función lineas de nivel con marching_squares para un caso simple 4x4.
    """

    bool_results = []
    msg_list = []

    # Casos a probar
    marching_squares_cases = {
        0: {"matrix": np.array([[10, 20], [30, 40]]), "threshold": 50},     # Case 0
        1: {"matrix": np.array([[60, 20], [30, 40]]), "threshold": 50},     # Case 1
        2: {"matrix": np.array([[20, 70], [30, 40]]), "threshold": 50},     # Case 2
        3: {"matrix": np.array([[80, 90], [30, 40]]), "threshold": 50},     # Case 3
        4: {"matrix": np.array([[10, 20], [70, 30]]), "threshold": 50},     # Case 4
        5: {"matrix": np.array([[60, 20], [80, 30]]), "threshold": 50},     # Case 5
        6: {"matrix": np.array([[20, 80], [90, 40]]), "threshold": 50},     # Case 6
        7: {"matrix": np.array([[70, 90], [60, 40]]), "threshold": 50},     # Case 7
        8: {"matrix": np.array([[10, 20], [30, 100]]), "threshold": 50},    # Case 8
        9: {"matrix": np.array([[60, 20], [30, 70]]), "threshold": 50},     # Case 9
        10: {"matrix": np.array([[20, 70], [30, 90]]), "threshold": 50},    # Case 10
        11: {"matrix": np.array([[60, 70], [30, 90]]), "threshold": 50},    # Case 11
        12: {"matrix": np.array([[10, 20], [90, 100]]), "threshold": 50},   # Case 12
        13: {"matrix": np.array([[70, 20], [80, 90]]), "threshold": 50},    # Case 13
        14: {"matrix": np.array([[20, 80], [70, 90]]), "threshold": 50},    # Case 14
        15: {"matrix": np.array([[60, 70], [80, 90]]), "threshold": 50}     # Case 15
    }
    # Casos y sus resultados esperados
    ms_expected_results = {
        0: [],                                                              # Case 0
        1: [[(0, 0.3333333333333333), (0.25, 0)]],                          # Case 1
        2: [[(0.6, 0), (1, 0.6666666666666666)]],                           # Case 2
        3: [[(0, 0.6), (1, 0.8)]],                                          # Case 3
        4: [[(0, 0.6666666666666666), (0.5, 1)]],                           # Case 4
        5: [[(0.25, 0), (0.6, 1)]],                                         # Case 5
        6: [[(0, 0.42857142857142855), (0.5, 0)], [(0.8, 1), (1, 0.75)]],   # Case 6
        7: [[(0.5, 1), (1, 0.8)]],                                          # Case 7
        8: [[(0.2857142857142857, 1), (1, 0.375)]],                         # Case 8
        9: [[(0, 0.3333333333333333), (0.5, 1)], [(0.25, 0), (1, 0.6)]],    # Case 9
        10: [[(0.6, 0), (0.3333333333333333, 1)]],                          # Case 10
        11: [[(0, 0.3333333333333333), (0.3333333333333333, 1)]],           # Case 11
        12: [[(0, 0.5), (1, 0.375)]],                                       # Case 12
        13: [[(0.4, 0), (1, 0.42857142857142855)]],                         # Case 13
        14: [[(0, 0.6), (0.5, 0)]],                                         # Case 14
        15: []                                                              # Case 15
    }

    # Verificar todos los casos
    for case, data in marching_squares_cases.items():

        case_result = True

        matrix = data["matrix"]
        threshold = data["threshold"]
        result = marching_squares_func(matrix, threshold)

        try:
            result_len = len(result)
            exp_len = len(ms_expected_results[case])

            # Verificar cantidad de segmentos
            if result_len != exp_len:
                msg_list.append(f'\nFALLA caso {case} de marching squares.\nSe encuentran {result_len} segmentos != {exp_len} segmentos esperados:')
                msg_list.append(f'Implementación:\t{result}\nEsperado:\t{ms_expected_results[case]}\n')
                case_result = False
            
            # Verificar coordenadas de segmentos
            for line, exp_line in zip(result, ms_expected_results[case]):
                lines_equal = (line == exp_line)
                lines_inv_equal = (line == exp_line[::-1])
                if not(lines_equal or lines_inv_equal):
                    msg_list.append(f"\nFALLA el caso {case}, con matriz:\n{matrix} \ny nivel:\n{threshold}.\nImplementación:\t{result}\nEsperado:\t{ms_expected_results[case]}\n")
                    case_result = False
                
        except Exception as e:
            print(f"ERROR EN EJECUCIÓN para el caso {case}, con matriz: {matrix} \n y nivel {threshold}:")
            print(e,'\n')
            case_result = False
        
        if case_result:
                msg_list.append(f'APRUEBA caso {case} de marching squares.')
        
        bool_results.append(case_result)

    for msg in msg_list:
        print(msg)

    return np.all(bool_results)

def test_histograma(histograma_func):
    """
    Test de función histograma.
    """

    RANGOS = {'None': None, 
              '0_100': (0,100), 
              '50_256': (50, 256), 
              '-255_25': (-255, 256)
              }
    ARRAYS = {'np.arange_0-100': np.arange(0,100), 
              'np.arange25_5x5': np.arange(25).reshape(5,5),
              'np.random.randint_10x10_-200low_256high': np.random.randint(low=-200,high=256, size=(10,10))
              }
    NBINS = {'10': 10,
             '100': 100,
             '256': 256
             }
    
    bool_results = []
    
    msg_list = []

    for arr_key, arr in ARRAYS.items():
        for nbins_key, nbins in NBINS.items():
            for rango_key, rango in RANGOS.items(): 

                error_image = False
                case_result = True

                try:

                    hist, bins = histograma_func(arr, nbins, rango)
                    if (len(bins) != len(hist) + 1):
                        msg_list.append(f"No se cumple la condición: {len(bins)=} == {len(hist)=} + 1")
                        case_result = False
                        

                    exp_hist, exp_bins = np.histogram(arr.flatten(), bins=nbins, range=rango)

                    if not np.allclose(bins,exp_bins, atol=1): 
                        msg_list.append(f"Hay diferencia entre los bins: {bins=}\n y los esperados\n{exp_bins=}")
                        case_result = False

                    hist_equal = np.allclose(hist,exp_hist)
                
                    if not hist_equal:

                        case_result = False

                        img_dir_path = os.path.join(os.getcwd(),'testing/hist_errors')
                        os.makedirs(img_dir_path, exist_ok=True)
                        img_save_path = os.path.join(img_dir_path, f'{arr_key}_BINS_{nbins_key}_RANGO_{rango_key}.png')

                        plt.figure(figsize=(12,4))
                        plt.title('Diferencia entre implementación y resultado esperado')

                        plt.bar(bins[:-1], hist, label='Implementación', color='red', alpha=0.3)
                        plt.bar(bins[:-1], exp_hist, label='Esperado', color='green', alpha=0.3)
                        
                        plt.legend()
                        plt.savefig(img_save_path)
                        plt.close()
                        error_image = True

                    if case_result:
                        msg_list.append(f"APRUEBA histograma usando ARRAY: {arr_key}, NBINS: {nbins_key} y RANGOS: {rango_key}.")
                    else:
                        msg_error = f"Hay diferencia entre los histogramas usando {nbins=}, {rango=} y arreglo {arr_key=}." + error_image*f"\nVer la imagen {img_save_path}\n"
                        msg_list.append(msg_error)

                except Exception as e:
                    msg = f'ERROR EN EJECUCIÓN usando ARRAY: {arr_key}, NBINS: {nbins_key} y RANGOS: {rango_key}.\n{e}\n'
                    msg_list.append(msg)

                bool_results.append(case_result)
    
    for msg in msg_list:
        print(msg)

    return np.all(bool_results)

def test_add_gaussian_noise(add_gaussian_func):

    # np.random.seed(21)

    bool_results = []
    
    msg_list = []

    Z = np.zeros((1024,1024))
    N = Z.shape[0] * Z.shape[1]

    test_sigmas = [1, 5, 10, 15, 20, 30, 50, 100]

    try:

        for sigma in test_sigmas:

            Z_noisy = add_gaussian_func(Z, sigma)    
            sigma_hat = np.std(Z_noisy)

            dist_data_sigma = np.count_nonzero((Z_noisy < sigma) & (Z_noisy > -sigma)) / N
            dist_data_2sigma = np.count_nonzero((Z_noisy < 2*sigma) & (Z_noisy > -2*sigma)) / N
            data_sigma_bool = (dist_data_sigma > 0.678) and (dist_data_sigma < 0.688)
            data_2sigma_bool = (dist_data_2sigma > 0.953) and (dist_data_2sigma < 0.955)

            rel_error = np.abs(sigma-sigma_hat)/sigma

            if rel_error > 0.01:
                bool_results.append(False)
                msg_list.append(f"FALLA en el caso {sigma=}. Se tiene un error relativo del sigma estimado mayor al 1%")
            if not data_sigma_bool:
                bool_results.append(False)
                msg_list.append(f"FALLA en el caso {sigma=}. Intervalo [-sigma, sigma] no contiene aproximadamente el 68% de los valores generados por el ruido")
            if not data_2sigma_bool:
                bool_results.append(False)
                msg_list.append(f"FALLA en el caso {sigma=}. Intervalo [-2sigma, 2sigma] no contiene aproximadamente el 95.4% de los valores generados por el ruido")
            else:
                bool_results.append(True)
                msg_list.append(f"APRUEBA en el caso {sigma=}.")
                

    except Exception as e:
        bool_results.append(False)
        msg = f'ERROR EN EJECUCIÓN de la función:\n{e}\n'
        msg_list.append(msg)

    for msg in msg_list:
        print(msg)

    return np.all(bool_results)


def test_add_saltpepper_noise(add_saltpepper_func):

    # np.random.seed(21)
    
    bool_results = []
    
    msg_list = []

    Z = 127 * np.ones((1024,1024))
    N = Z.shape[0] * Z.shape[1]

    test_ps = [0.001, 0.01, 0.05, 0.1, 0.2, 0.3, 0.5, 0.8]

    try:

        for p in test_ps:

            Z_noisy = add_saltpepper_func(Z, p)    
            pepper_amount = np.count_nonzero(Z_noisy==0)
            salt_amount = np.count_nonzero(Z_noisy==255)

            p_hat = (pepper_amount + salt_amount) /  N

            rel_error = np.abs(p-p_hat)/p

            if rel_error > 0.10:
                bool_results.append(False)
                msg_list.append(f"FALLA en el caso {p=}. Se tiene un error relativo mayor al 10%")
            else:
                bool_results.append(True)
                msg_list.append(f"APRUEBA en el caso {p=}.")
                

    except Exception as e:
        bool_results.append(False)
        msg = f'ERROR EN EJECUCIÓN de la función:\n{e}\n'
        msg_list.append(msg)

    for msg in msg_list:
        print(msg)

    return np.all(bool_results)